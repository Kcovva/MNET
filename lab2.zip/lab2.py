"""ЛР2: збір даних Docker CLI та Docker Engine API через SSH."""

import argparse
import csv
from datetime import datetime, timezone
from getpass import getpass
import ipaddress
import json
from pathlib import Path
import shlex
import sys

import docker
import paramiko
import requests


HANDLED_ERRORS = (OSError, paramiko.SSHException, docker.errors.DockerException,
                  RuntimeError, ValueError, KeyError)


def run_command(ssh, command):
    """Виконати команду, показати результат і перевірити код завершення."""
    print(f"\n$ {command}", flush=True)
    stdin, stdout, stderr = ssh.exec_command(command, timeout=10)
    stdin.close()
    output = stdout.read().decode("utf-8", errors="replace").strip()
    error = stderr.read().decode("utf-8", errors="replace").strip()
    exit_code = stdout.channel.recv_exit_status()
    print(output or "(порожній вивід)")
    if exit_code != 0:
        raise RuntimeError(f"Код завершення {exit_code}: {error or output}")
    if error:
        print(f"Повідомлення Docker: {error}", file=sys.stderr)
    return output


def collect_cli(ssh, project):
    """Зібрати відомості лише про контейнери заданого Compose-проєкту."""
    label = shlex.quote(f"label=com.docker.compose.project={project}")
    ps_template = shlex.quote("{{.ID}} {{.Names}} {{.Image}} {{.State}}")
    output = run_command(
        ssh,
        f"docker ps -a --no-trunc --filter {label} --format {ps_template}",
    )
    if not output:
        raise RuntimeError(f"Не знайдено контейнерів Compose-проєкту {project!r}.")

    # Перший рядок — сервіс і час запуску; наступні — мережа та IPv4.
    inspect_template = shlex.quote(
        '{{println (index .Config.Labels "com.docker.compose.service") .State.StartedAt}}'
        '{{range $name, $network := .NetworkSettings.Networks}}'
        '{{println $name $network.IPAddress}}{{end}}'
    )
    containers = []
    for line in output.splitlines():
        container_id, name, image, state = line.split()
        details = run_command(
            ssh, f"docker inspect --format {inspect_template} {shlex.quote(container_id)}"
        ).splitlines()
        service, started_at = details[0].split()
        networks = {}
        for network_line in details[1:]:
            fields = network_line.split()
            if fields:
                networks[fields[0]] = fields[1] if len(fields) > 1 else ""

        port_output = run_command(ssh, f"docker port {shlex.quote(container_id)}")
        published_ports = []
        for port_line in port_output.splitlines():
            container_port, host_binding = port_line.split(" -> ", 1)
            host_ip, host_port = host_binding.rsplit(":", 1)
            published_ports.append({
                "container_port": container_port,
                "host_ip": host_ip.strip("[]"),
                "host_port": int(host_port),
            })

        containers.append({
            "id": container_id,
            "name": name,
            "service": service,
            "image": image,
            "state": state,
            "started_at": started_at,
            "networks": networks,
            "published_ports": published_ports,
        })
    return containers


def collect_api(client, project):
    """Отримати структуровані дані Docker Engine API через SDK."""
    objects = client.containers.list(
        all=True,
        filters={"label": f"com.docker.compose.project={project}"},
    )
    if not objects:
        raise RuntimeError(f"Не знайдено контейнерів Compose-проєкту {project!r}.")

    containers = []
    for container in objects:
        attrs = container.attrs
        network_settings = attrs["NetworkSettings"]
        networks = {
            name: settings.get("IPAddress", "")
            for name, settings in network_settings["Networks"].items()
        }
        published_ports = []
        for container_port, bindings in (network_settings["Ports"] or {}).items():
            # None означає, що порт не має прив'язки до хоста.
            for binding in bindings or []:
                published_ports.append({
                    "container_port": container_port,
                    "host_ip": binding["HostIp"],
                    "host_port": int(binding["HostPort"]),
                })

        containers.append({
            "id": container.id,
            "name": container.name,
            "service": container.labels["com.docker.compose.service"],
            "image": attrs["Config"]["Image"],
            "state": attrs["State"]["Status"],
            "started_at": attrs["State"]["StartedAt"],
            "networks": networks,
            "published_ports": published_ports,
        })
    return containers


def normalize_containers(containers):
    """Однакові типи значень і порядок елементів для обох способів збору."""
    normalized = []
    for container in containers:
        item = dict(container)
        item["id"] = str(item["id"]).strip().lower()
        if len(item["id"]) != 64 or any(char not in "0123456789abcdef" for char in item["id"]):
            raise ValueError("Очікувався повний 64-символьний ID контейнера.")
        for field in ("name", "service", "image", "state"):
            item[field] = str(item[field]).strip()
        item["state"] = item["state"].lower()
        started = datetime.fromisoformat(item["started_at"].replace("Z", "+00:00"))
        item["started_at"] = started.astimezone(timezone.utc).isoformat()
        item["networks"] = {
            name: str(ipaddress.ip_address(ip)) if ip else ""
            for name, ip in sorted(item["networks"].items())
        }
        ports = []
        for binding in item["published_ports"]:
            host_ip = str(binding["host_ip"]).strip("[]")
            ports.append({
                "container_port": str(binding["container_port"]),
                "host_ip": str(ipaddress.ip_address(host_ip)) if host_ip else "",
                "host_port": int(binding["host_port"]),
            })
        item["published_ports"] = sorted(
            ports, key=lambda port: (port["container_port"], port["host_ip"], port["host_port"])
        )
        normalized.append(item)
    ids = [item["id"] for item in normalized]
    if len(ids) != len(set(ids)):
        raise ValueError("У знімку виявлено повторення ID контейнера.")
    return sorted(normalized, key=lambda item: item["id"])


def make_snapshot(hostname, project, containers):
    return {
        "hostname": hostname.strip(),
        "project": project,
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "containers": normalize_containers(containers),
    }


def collect_cli_snapshot(args):
    password = getpass("Пароль користувача Ubuntu: ")
    with paramiko.SSHClient() as ssh:
        ssh.load_host_keys(str(Path.home() / ".ssh" / "known_hosts"))
        ssh.connect(
            hostname=args.host, port=args.port, username=args.user,
            password=password, allow_agent=False, look_for_keys=False,
            timeout=10, banner_timeout=10, auth_timeout=10,
        )
        if args.command:
            run_command(ssh, args.command)
            return None
        hostname = run_command(ssh, "hostname")
        containers = collect_cli(ssh, args.project)
    return make_snapshot(hostname, args.project, containers)


def collect_api_snapshot(args):
    client = docker.DockerClient(
        base_url=f"ssh://{args.user}@{args.host}:{args.port}",
        version="auto", timeout=10,
    )
    try:
        hostname = client.info()["Name"]
        containers = collect_api(client, args.project)
    finally:
        client.close()
    return make_snapshot(hostname, args.project, containers)


def check_network(containers):
    """Таблиця мереж та перевірка публікації портів проєкту ЛР1."""
    members = {}
    violations = []
    services = {container["service"] for container in containers}
    for service in sorted({"proxy", "app", "db"} - services):
        violations.append(f"Не знайдено очікуваного сервісу {service}.")
    for container in containers:
        name = container["name"]
        for network in container["networks"]:
            members.setdefault(network, []).append(name)
        bindings = container["published_ports"]
        if container["service"] == "proxy":
            if not bindings:
                violations.append(f"{name}: веб-проксі не має опублікованого порту.")
        elif bindings:
            ports = ", ".join(
                f'{port["host_ip"]}:{port["host_port"]} -> {port["container_port"]}'
                for port in bindings
            )
            violations.append(f"{name}: зайві прив'язки до хоста: {ports}.")
    return {
        "passed": not violations,
        "verdict": "відповідає вимогам" if not violations else "виявлено порушення",
        "networks": {name: sorted(names) for name, names in sorted(members.items())},
        "violations": violations,
    }


def check_http(proxy_url):
    """Два послідовні запити, час до заголовків і перевірка лічильника."""
    results = []
    for number in (1, 2):
        item = {"request": number, "status": None, "elapsed_seconds": None,
                "visits": None, "error": None}
        try:
            with requests.get(proxy_url, timeout=5) as response:
                item["status"] = response.status_code
                item["elapsed_seconds"] = response.elapsed.total_seconds()
                response.raise_for_status()
                body = response.json()
                if not isinstance(body, dict) or type(body.get("visits")) is not int:
                    raise ValueError("Відповідь не містить цілочислового лічильника visits.")
                item["visits"] = body["visits"]
        except (requests.RequestException, ValueError) as error:
            item["error"] = str(error)
        results.append(item)

    first, second = results
    passed = (all(item["error"] is None for item in results)
              and second["visits"] > first["visits"])
    if passed:
        detail = f'Лічильник збільшився: {first["visits"]} -> {second["visits"]}.'
        if second["visits"] - first["visits"] > 1:
            detail += " Між перевірками могли надійти інші запити."
    else:
        detail = "Не підтверджено дві успішні відповіді зі збільшенням лічильника."
    return {"url": proxy_url, "passed": passed, "requests": results, "details": detail}


def compare_snapshots(cli_snapshot, api_snapshot):
    """Зіставлення за повним ID; порядок списків не впливає на результат."""
    differences = []
    for field in ("hostname", "project"):
        if cli_snapshot[field] != api_snapshot[field]:
            differences.append({"field": field, "cli": cli_snapshot[field], "api": api_snapshot[field]})
    cli = {item["id"]: item for item in normalize_containers(cli_snapshot["containers"])}
    api = {item["id"]: item for item in normalize_containers(api_snapshot["containers"])}
    for container_id in sorted(cli.keys() | api.keys()):
        if container_id not in cli or container_id not in api:
            differences.append({
                "id": container_id, "field": "container_presence",
                "cli": container_id in cli, "api": container_id in api,
            })
            continue
        for field in ("state", "networks", "published_ports"):
            if cli[container_id][field] != api[container_id][field]:
                differences.append({
                    "id": container_id, "name": cli[container_id]["name"], "field": field,
                    "cli": cli[container_id][field], "api": api[container_id][field],
                })
    return {"passed": not differences, "differences": differences}


def save_results(result, output_dir):
    """JSON зі знімками та CSV з підсумками всіх перевірок."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    inventory_path = output_dir / "inventory.json"
    report_path = output_dir / "report.csv"
    inventory_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = []
    for source in ("cli", "api"):
        snapshot = result[source]
        if snapshot is None:
            rows.append([source, "collection", "FAIL", result["errors"][source]])
            continue
        rows.append([source, "collection", "PASS", f'Контейнерів: {len(snapshot["containers"])}'])
        network = result["network_checks"][source]
        for name, members in network["networks"].items():
            rows.append([source, "network_membership", "INFO", f'{name}: {", ".join(members)}'])
        rows.append([source, "port_publishing", "PASS" if network["passed"] else "FAIL",
                     network["verdict"] if network["passed"] else " ".join(network["violations"])])
    http = result["http_check"]
    for item in http["requests"]:
        rows.append(["http", f'request_{item["request"]}', "FAIL" if item["error"] else "PASS",
                     json.dumps(item, ensure_ascii=False)])
    rows.append(["http", "counter_increase", "PASS" if http["passed"] else "FAIL", http["details"]])
    comparison = result["comparison"]
    if comparison["differences"]:
        for difference in comparison["differences"]:
            rows.append(["cli_api", "comparison", "FAIL", json.dumps(difference, ensure_ascii=False)])
    else:
        rows.append(["cli_api", "comparison", "PASS", "Склад, стани, мережі та прив'язки портів збігаються."])
    # BOM допомагає Excel у Windows правильно визначити українське кодування.
    with report_path.open("w", encoding="utf-8-sig", newline="") as report:
        writer = csv.writer(report)
        writer.writerow(["source", "check", "result", "details"])
        writer.writerows(rows)
    return inventory_path, report_path


def run_full_check(args):
    result = {
        "project": args.project, "collected_at": datetime.now(timezone.utc).isoformat(),
        "cli": None, "api": None, "errors": {}, "network_checks": {},
    }
    for source, collector in (("cli", collect_cli_snapshot), ("api", collect_api_snapshot)):
        try:
            snapshot = collector(args)
            network = check_network(snapshot["containers"])
            result[source] = snapshot
            result["network_checks"][source] = network
            print(f"\n{source.upper()}: хост {snapshot['hostname']}, проєкт {args.project}")
            print(f"Мережа -> контейнери ({source.upper()}):")
            for name, members in network["networks"].items():
                print(f'  {name} -> {", ".join(members)}')
            print(f"Публікація портів: {network['verdict']}")
            for violation in network["violations"]:
                print(f"  {violation}")
        except HANDLED_ERRORS as error:
            result["errors"][source] = str(error)
            print(f"\nПОМИЛКА {source.upper()}: {error}", file=sys.stderr)

    result["http_check"] = check_http(args.proxy_url)
    for item in result["http_check"]["requests"]:
        print(f"\nHTTP-запит {item['request']}: {json.dumps(item, ensure_ascii=False)}")
    print(result["http_check"]["details"])
    if result["cli"] is not None and result["api"] is not None:
        result["comparison"] = compare_snapshots(result["cli"], result["api"])
    else:
        result["comparison"] = {
            "passed": False,
            "differences": [{"field": "collection", "reason": "Для порівняння потрібні успішні знімки CLI та API."}],
        }
    comparison = result["comparison"]
    print("\nПорівняння CLI/API: " + ("дані збігаються" if comparison["passed"] else "виявлено відмінності"))
    for difference in comparison["differences"]:
        print(json.dumps(difference, ensure_ascii=False))
    if not comparison["passed"]:
        print("Перевір відмінності: можливі помилка обробки або зміна стану між опитуваннями.")
    paths = save_results(result, args.output_dir)
    for path in paths:
        print(f"Збережено: {path.resolve()}")
    passed = (not result["errors"] and result["http_check"]["passed"] and comparison["passed"]
              and all(check["passed"] for check in result["network_checks"].values()))
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1", help="Адреса SSH-хоста")
    parser.add_argument("--port", type=int, default=2222, help="Порт SSH")
    parser.add_argument("--user", default="diana", help="Користувач Ubuntu")
    parser.add_argument("--project", default="mnet-lab1", help="Назва Compose-проєкту")
    parser.add_argument("--method", choices=["cli", "api", "both"], default="cli", help="Спосіб збору; both — повна перевірка")
    parser.add_argument("--command", help="Виконати одну перевірочну команду замість збору")
    parser.add_argument("--proxy-url", default="http://127.0.0.1:8080/", help="Адреса веб-проксі, доступна з Windows")
    parser.add_argument("--output-dir", default=".", help="Папка для inventory.json і report.csv")
    args = parser.parse_args()

    try:
        if args.command and args.method != "cli":
            raise ValueError("Параметр --command використовується лише з --method cli.")
        if args.method == "both":
            return run_full_check(args)
        if args.method == "api":
            snapshot = collect_api_snapshot(args)
            print(f"Docker SDK for Python: {docker.__version__}")
            print(f"Compose-проєкт: {args.project}")
            print("\nОБРОБЛЕНІ ДАНІ API:")
            print(json.dumps(snapshot, ensure_ascii=False, indent=2))
            print(f"\nЗбір API завершено. Контейнерів: {len(snapshot['containers'])}.")
            return 0

        snapshot = collect_cli_snapshot(args)
        if snapshot is not None:
            print("\nОБРОБЛЕНІ ДАНІ CLI:")
            print(json.dumps(snapshot, ensure_ascii=False, indent=2))
            print(f"\nЗбір CLI завершено. Контейнерів: {len(snapshot['containers'])}.")
        return 0
    except HANDLED_ERRORS as error:
        print(f"\nПОМИЛКА: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
