from flask import Flask
from redis import Redis

app = Flask(__name__)

db = Redis(
    host="db",
    port=6379,
    socket_connect_timeout=3,
    socket_timeout=3,
)


@app.get("/")
def index():
    visits = db.incr("visits")
    return {"visits": visits}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
